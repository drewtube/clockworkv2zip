# Security Policy

Only the latest beta version is supported. As of writing, this is 2.0.0.0-beta15.

## Reporting a Vulnerability

Send an email to our Trust & Safety team at [trustsafety@mail.redstonenetwork.rit.cl](mailto:trustsafety@mail.redstonenetwork.rit.cl). It'll be the quickest and easiest way to get it fixed.
